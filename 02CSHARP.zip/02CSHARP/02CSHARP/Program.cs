﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


//1.Заполнить одномерный массив случайными числами из диапазона от –100 до 100, затем
//преобразовать массив так, чтобы сначала шли все отрицательные элементы, а потом положительные (0 считать положительным).

//2.Дан двумерный массив размерностью 5?5, заполненный случайными числами из диапазона от –100 до 100.
//Определить сумму элементов массива, расположенных
//между минимальным и максимальным элементами.

namespace _02CSHARP
{
    class Program
    {
        static void Main(string[] args)
        {
            ////1Z
            //int[] mass = new int[100];
            //Random random = new Random();

            //for (int i = 0; i < 100; i++)
            //{
            //    mass[i] = random.Next(-100, 100);
            //}

            //Console.WriteLine(string.Join(", ", mass));
            //Array.Sort(mass, (a, b) => Math.Sign(b) - Math.Sign(a));

            //Console.WriteLine(string.Join(", ", mass));


            ////Array.Sort  -сортирует массив
            ////String.Join -может просмотреть все строки, чтобы определить точную длину, которая ему нужна, а затем снова пойти и скопировать все данные. Это означает, что не будет никакого дополнительного копирования.
            ////Math.Sign   -возвращает число 1, если число value положительное, и -1, если значение value отрицательное. Если value равно 0, то возвращает 0


            Console.WriteLine("=============================================================================================");
            int temp = 0, c = 0;
            int size1 = 3;
            int[] array1 = new int[size1];
            Random random1 = new Random();

            for (int i = 0; i < size1; i++)//заполняем одномерный массив random значениями
            {
                array1[i] = random1.Next(-100, 100);
                Console.Write(" " + array1[i]);
            }

            for(int i = 0; i < size1; i++)
            {
                for (int j = 0; j < size1-1; j++)
                {
                    //int temp = 0, c = 0;

                    if (array1[j] < 0)
                    {
                        temp = array1[j];
                        c = array1[j];
                        array1[j] = temp;
                        array1[j] = c;
                      

                    }
                }
            }

            Console.WriteLine(" " + array1 );

            Console.WriteLine("=============================================================================================");

            //2Z

            int size = 3; 
            int[,] array = new int[size,size];
            Random random = new Random();

            for (int i = 0; i < size; i++)//заполняем двумерный массив random значениями
            {
                for (int j = 0; j < size; j++)
                {
                    array[i, j] = random.Next(-100, 100);
                    Console.Write(" " + array[i, j]);
                }
                Console.WriteLine();
            }

            int sum = 0;
            int min = array[0, 0], max = array[0, 0];
            int mini = 0, maxi = 0;
            int minj = 0, maxj = 0;


            for (int i = 0; i < size; i++)//ищем минимум и максимум в двумерном массиве
            {
                for (int j = 0; j < size; j++)
                {
                    if (array[i, j] < min)
                    {
                        min = array[i, j];
                        maxi = i;
                        maxj = j;
                    }
                    if (array[i, j] > max)
                    {
                        max = array[i, j];
                        mini = i;
                        minj = j;
                    }
                }  
            }
         
           
            for (int i = mini; i <= maxi; i++)//неправильно считает сумму
            {
                for (int j = minj; j < maxj; j++)
                {
                    sum += array[i, j];
                }       
            }

            Console.WriteLine(" MIN " + min);//результат минимума
            Console.WriteLine(" MAX " + max);//результат максимума
            Console.WriteLine(" SUM " + sum);//сумма 

            

            //Console.WriteLine("iMin: " + iMin);
            //Console.WriteLine("jMin: " + jMin);
            //Console.WriteLine("iMax: " + iMax);
            //Console.WriteLine("jMax: " + jMax);

           

            Console.ReadKey();

        }
    }
}
