﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
 
 class Car
{
    private string carModel;     // модель автомобиля
    private string enginesType;  //тип двигателя
    private double engineVolume; //обьем двигателя
    private int    enginePower;  //мощность двигателя
    private int    maxSpeed;     //максимальная скорость

    public Car()
	{
        carModel = "default";
        enginesType = "default";
        engineVolume = 0;
        enginePower = 0;
        maxSpeed = 0;
            //Print();
    }
    public Car(string _carModel, string _enginesType, double _engineVolume, int _enginePower, int _maxSpeed)
    {
        carModel     = _carModel;
        enginesType  = _enginesType;
        engineVolume = _engineVolume;
        enginePower  = _enginePower;
        maxSpeed     = _maxSpeed;
       // Print();
    }
    public Car(string _carModel)
    {
        carModel = _carModel;
       // Print();
    }
    public void Print()
    {
        Console.WriteLine("carModel     = " + carModel);
        Console.WriteLine("enginesType  = " + enginesType);
        Console.WriteLine("enginePower  = " + enginePower);
        Console.WriteLine("engineVolume = " + engineVolume);
        Console.WriteLine("maxSpeed     = " + maxSpeed);
        
    }
    public void Print(ref Car obj)
    {
        Console.WriteLine("carModel     = " + obj.carModel);
        Console.WriteLine("enginesType  = " + obj.enginesType);
        Console.WriteLine("enginePower  = " + obj.enginePower);
        Console.WriteLine("engineVolume = " + obj.engineVolume);
        Console.WriteLine("maxSpeed     = " + obj.maxSpeed);
    }

}
