﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _03CHARP
{
  public partial class Car
  {
        public void PrintHello()
        {
               Console.WriteLine("heeeloo");
        }
  }
}
