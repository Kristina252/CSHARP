﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//Задание 1.
//Написать программу, которая считывает символы с клавиатуры, пока не будет введена точка. Программа должна
//сосчитать количество введенных пользователем пробелов.

//Задание 2.
//Ввести с клавиатуры номер трамвайного билета (6-значное
//число) и проверить является ли данный билет счастливым
//(если на билете напечатано шестизначное число, и сумма
//первых трёх цифр равна сумме последних трёх, то этот
//билет считается счастливым).

namespace _01CSHARP
{
    class Program
    {
        static void Main(string[] args)
        {
            //не получилось через стринг?
            //string name;
            //Console.WriteLine("Input your name: ");
            //name = Console.ReadLine();
            //Console.WriteLine("Hello " + name);
            //string space;
            //int spaсeСounter = 0;
            //int rez = 0;
            //Console.WriteLine("Enter a space: ");
            //space = Console.ReadLine();
            //do
            //{
            //   Console.WriteLine("Please,Enter a Space: ");
            //     space = Console.ReadLine();
            //} while (space != " ");        
            //    if (space == " ")
            //        spaсeСounter++;
            //Console.WriteLine("Rezult: " + spaсeСounter);

            //1Z.подчет пробелов
            //1Zcounting spaces

            char space ;
            int spaceCounter = 0;
             
            Console.WriteLine(" This program is designed to count spaces. To display the result, please press( = ) ");
            Console.WriteLine(" Enter a space: ");
            space = Console.ReadKey().KeyChar;

            if(space !=' ')
            {
                do
                {
                    Console.WriteLine("Please, Enter a space: ");
                    space = Console.ReadKey().KeyChar;
           
                } while (space != ' ');
            }

            do
            {
                space = Console.ReadKey().KeyChar;
                if (space == ' ' )
                    spaceCounter++;

            } while (space != '.' );

            Console.WriteLine(" Result : " +  spaceCounter);
            //Console.WriteLine(" To close the console press Inter");


            //2Z.проверка счастливого билета
            //2Z.lucky ticket check

            char z;
            int number = 0;
            int a = 0, b = 0, c = 0, d = 0, e = 0, f = 0;
          
            Console.WriteLine("If a six-digit number is printed on the ticket, and the amountthe first three digits is equal to the sum of the last three, then thisthe ticket is considered lucky");

            Console.WriteLine("Enter the tram ticket number (six-digit number): ");
            number = int.Parse(Console.ReadLine());

            a = number % 10;
            b = (number / 10) % 10;
            c = (number / 100) % 10;
            d = (number / 1000) % 10;
            e = (number / 10000) % 10;
            f = (number / 100000) % 10;

            if (a + b + c == e + d + f)
                Console.WriteLine("+++++++++++++WINNER+++++++++++++++");

            else if (a + b + c != e + d + f)
            Console.WriteLine("You have LOST, you have two attempts left! If you want to continue the game, press (+), if finished (-): ");
            z = Console.ReadKey().KeyChar;
            
            if(z == '+')
            {
                Console.WriteLine("Enter the tram ticket number (six-digit number): ");
                number = int.Parse(Console.ReadLine());

                a = number % 10;
                b = (number / 10) % 10;
                c = (number / 100) % 10;
                d = (number / 1000) % 10;
                e = (number / 10000) % 10;
                f = (number / 100000) % 10;

                if (a + b + c == e + d + f)
                    Console.WriteLine("+++++++++++++WINNER+++++++++++++++");
                else if (a + b + c != e + d + f)
                    Console.WriteLine("You have LOST, you have one attempts left! If you want to continue the game, press (+), if finished (-): ");
                z = Console.ReadKey().KeyChar;

                if(z == '+')
                {
                    Console.WriteLine("Enter the tram ticket number (six-digit number): ");
                    number = int.Parse(Console.ReadLine());

                    a = number % 10;
                    b = (number / 10) % 10;
                    c = (number / 100) % 10;
                    d = (number / 1000) % 10;
                    e = (number / 10000) % 10;
                    f = (number / 100000) % 10;

                    if (a + b + c == e + d + f)
                        Console.WriteLine("+++++++++++++WINNER+++++++++++++++");
                    else if (a + b + c != e + d + f)
                        Console.WriteLine("-------------YOU LOST-------------");

                }
                else if (z != '+')
                    Console.WriteLine("*****************GOODBAY******************");

            }
            else if(z != '+')
                Console.WriteLine("*****************GOODBAY******************");


            Console.WriteLine(" ");
            Console.ReadKey();

        }
    }
}




